for i=1:14
% CIVE 
ipath=['C:\Users\SOULMATE\Desktop\double_experiment\data_cut&selected\orign\' ,num2str(i), '\'];
allFiles = dir([ipath, '*mer5.jpg']); % 获取所有以 nor.jpg 结尾的文件名
    for j = 1:length(allFiles)
        a1=imread([ipath, allFiles(j).name]);
        [h1,~,nVe] = rgb2hsv(a1);
        a1=double(a1);
        CIVE = 0.441*a1(:,:,1)-0.811*a1(:,:,2)+0.385*a1(:,:,3)+18.78745;
        CIVE1=rescale(CIVE);
        clear CIVE
        [~,kxd0]=graythresh(CIVE1); 
        bw=imbinarize(CIVE1);
        cw=uint8(~bw);
        cw(cw==1)=255;
        imwrite(cw,[ipath,'\mer5CIVE.tif'])
        clear bw cw
    end
end
%EXG大津阈值分类 256灰度迭代
for i=1:14
% 实验数据统一放于一个文件夹中，一组数据放于对应序号文件夹中 
ipath=['C:\Users\SOULMATE\Desktop\double_experiment\data_cut&selected\orign\' ,num2str(i), '\'];
allFiles = dir([ipath, '*mer5.jpg']); % 获取所有以 nor.jpg 结尾的文件名
    for j = 1:length(allFiles)
        a1=imread([ipath, allFiles(j).name]);
        [h1,~,nVe] = rgb2hsv(a1);
        a1=double(a1);
        EXG = 2*a1(:,:,2)-a1(:,:,1)-a1(:,:,3);
        EXG1=rescale(EXG);
        clear EXG
% 将EXG归一化 kxd0为大津阈值的可信度 可信度高证明二分效果好 bw为黑白二值化
        bw=imbinarize(EXG1);
        cw=uint8(~bw);
        cw(cw==0)=255;
        cw(cw==1)=0;
        imwrite(cw,[ipath,'\mer5EXG.tif'])
        clear a1 bw cw
    end
end
%EXGR大津阈值分类 256灰度迭代
for i=1:14
% 实验数据统一放于一个文件夹中，一组数据放于对应序号文件夹中 
ipath=['C:\Users\SOULMATE\Desktop\double_experiment\data_cut&selected\orign\' ,num2str(i), '\'];
allFiles = dir([ipath, '*mer5.jpg']); % 获取所有以 nor.jpg 结尾的文件名
    for j = 1:length(allFiles)
        a1=imread([ipath, allFiles(j).name]);
        a1=double(a1);
        EXGR = (2*a1(:,:,2)-a1(:,:,1)-a1(:,:,3))-(1.4*a1(:,:,1)-a1(:,:,2));
        EXGR1=rescale(EXGR);
        clear EXGR
% 将EXG归一化 kxd0为大津阈值的可信度 可信度高证明二分效果好 bw为黑白二值化
        bw=imbinarize(EXGR1);
        cw=uint8(~bw);
        cw(cw==0)=255;
        cw(cw==1)=0;
        imwrite(cw,[ipath,'mer5EXGR.tif'])
        clear a1 bw cw
    end
end
%EXR大津阈值分类 256灰度迭代
for i=1:14
% 实验数据统一放于一个文件夹中，一组数据放于对应序号文件夹中 
ipath=['C:\Users\SOULMATE\Desktop\double_experiment\data_cut&selected\orign\' ,num2str(i), '\'];
allFiles = dir([ipath, '*mer5.jpg']); % 获取所有以 nor.jpg 结尾的文件名
    for j = 1:length(allFiles)
        a1=imread([ipath, allFiles(j).name]);
        a1=double(a1);
        EXR = 1.4*a1(:,:,1)-a1(:,:,2);
        EXR1=rescale(EXR);
        clear EXR
% 将EXG归一化 kxd0为大津阈值的可信度 可信度高证明二分效果好 bw为黑白二值化
        bw=imbinarize(EXR1);
        cw=uint8(~bw);
        cw(cw==1)=255;
        imwrite(cw,[ipath,'\mer5EXR.tif'])
        clear a1 bw cw
    end
end
%HUE
for i=1:14
% 实验数据统一放于一个文件夹中，一组数据放于对应序号文件夹中 
ipath=['C:\Users\SOULMATE\Desktop\double_experiment\data_cut&selected\orign\' ,num2str(i), '\'];
allFiles = dir([ipath, '*mer5.jpg']); % 获取所有以 nor.jpg 结尾的文件名
    for j = 1:length(allFiles)
        a1=imread([ipath, allFiles(j).name]);
        [h1,~,nVe] = rgb2hsv(a1);
        a1=double(a1);
        h2=rescale(h1);
        clear h1
        bw=imbinarize(h2);
        cw=uint8(~bw);
        cw(cw==0)=255;
        cw(cw==1)=0;
        imwrite(cw,[ipath,'\mer5Hsv.tif'])
        clear a1 bw cw
    end
end

