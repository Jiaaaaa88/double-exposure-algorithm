kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    g1=imread(ipath+'1.tif');
    [m n]=size(n1);
%     kk(i,3)=double(sum(sum(n1==t1&n1~=0)))/m/n;
%     kk(i,4)=double(sum(sum(m1==t1&m1~=0)))/m/n;
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==g1&n1~=0));
    k(1,2)=sum(sum(n1~=g1&n1==0));
    k(2,1)=sum(sum(n1~=g1&n1~=0));
    k(2,2)=sum(sum(n1==g1&n1==0));
    k=double(k);
    nIOU=(k(1,1))/(k(1,1)+k(1,2)+k(2,1));
    kk(i,1)=nIOU;
    k=zeros(2,2);
    k(1,1)=sum(sum(m1==g1&m1~=0));
    k(1,2)=sum(sum(m1~=g1&m1==0));
    k(2,1)=sum(sum(m1~=g1&m1~=0));
    k(2,2)=sum(sum(m1==g1&m1==0));
    k=double(k);
    mIOU=(k(1,1))/(k(1,1)+k(1,2)+k(2,1));
    kk(i,2)=mIOU;
clear n1 m1 t1 n1 t1 m1  
end
kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    t1=imread(ipath+'1.tif');
    [m n]=size(t1);
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==t1&n1~=0));
    k(1,2)=sum(sum(n1~=t1&n1==0));
    k(2,1)=sum(sum(n1~=t1&n1~=0));
    k(2,2)=sum(sum(n1==t1&n1==0));
    k=double(k);
    pe=(sum(k(1,:))*sum(k(:,1))+sum(k(2,:))*sum(k(:,2)))/(sum(sum(k))*sum(sum(k)));
    pa=(k(1,1)+k(2,2))/sum(sum(k));
    nka=(pa-pe)/(1-pe);
    kk(i,1)=nka;
    k=zeros(2,2);
    h(1,1)=sum(sum(m1==t1&m1~=0));
    h(1,2)=sum(sum(m1~=t1&m1==0));
    h(2,1)=sum(sum(m1~=t1&m1~=0));
    h(2,2)=sum(sum(m1==t1&m1==0));
    h=double(h);
    phe=(sum(h(1,:))*sum(h(:,1))+sum(h(2,:))*sum(h(:,2)))/(sum(sum(h))*sum(sum(h)));
    pha=(h(1,1)+h(2,2))/sum(sum(h));
    mka=(pha-phe)/(1-phe);
    kk(i,2)=mka;
clear n1 m1 t1   
end
kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    g1=imread(ipath+'1.tif');
    [m n]=size(g1);
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==g1&n1~=0));
    k(1,2)=sum(sum(n1~=g1&n1==0));
    k(2,1)=sum(sum(n1~=g1&n1~=0));
    k(2,2)=sum(sum(n1==g1&n1==0));
    k=double(k);
    t1=(k(1,1))/(2*(k(1,1)+k(1,2)+k(2,1)));
    t2=(k(2,2))/(2*(k(2,2)+k(1,2)+k(2,1)));
    nmIOU=t1+t2;
    kk(i,1)=nmIOU;
    h=zeros(2,2);
    h(1,1)=sum(sum(m1==g1&m1~=0));
    h(1,2)=sum(sum(m1~=g1&m1==0));
    h(2,1)=sum(sum(m1~=g1&m1~=0));
    h(2,2)=sum(sum(m1==g1&m1==0));
    h=double(h);
    p1=(h(1,1))/(2*(h(1,1)+h(1,2)+h(2,1)));
    p2=(h(2,2))/(2*(h(2,2)+h(1,2)+h(2,1)));
    mmIOU=p1+p2;
    kk(i,2)=mmIOU;
    clear n1 m1 t1 t2 p1 p2 g1 m n k h
end
kk=zeros(10000,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+"\0-10%\"+""+i+".jpg");
    n11 = rgb2gray(n1)
    m1=imread(ipath+"\0-10%\"+""+i+".jpg");
    m11 = rgb2gray(m1)
    t1=imread(ipath+"\true\"+""+i+".jpg");
    t11 = rgb2gray(t1)
    [m n]=size(t11);
%     kk(i,3)=double(sum(sum(n1==t1&n1~=0)))/m/n;
%     kk(i,4)=double(sum(sum(m1==t1&m1~=0)))/m/n;
    k=zeros(2,2);
    k(1,1)=sum(sum(n11==t11&n11~=0));
    k(1,2)=sum(sum(n11~=t11&n11==0));
    k(2,1)=sum(sum(n11~=t11&n11~=0));
    k(2,2)=sum(sum(n11==t11&n11==0));
    k=double(k);

    nOA=(k(1,1)+k(2,2))/(k(1,1)+k(1,2)+k(2,1)+k(2,2));
    kk(i,1)=nOA;
    k=zeros(2,2);
    k(1,1)=sum(sum(m11==t11&m11~=0));
    k(1,2)=sum(sum(m11~=t11&m11==0));
    k(2,1)=sum(sum(m11~=t11&m11~=0));
    k(2,2)=sum(sum(m11==t11&m11==0));
    k=double(k);
    mOA=(k(1,1)+k(2,2))/(k(1,1)+k(1,2)+k(2,1)+k(2,2));
    kk(i,2)=mOA;
clear n1 m1 t1 n11 t11 m11  
end

kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    g1=imread(ipath+'1.tif');
    [m n]=size(g1);
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==g1&n1~=0));
    k(1,2)=sum(sum(n1~=g1&n1==0));
    k(2,1)=sum(sum(n1~=g1&n1~=0));
    k(2,2)=sum(sum(n1==g1&n1==0));
    k=double(k);
    nOA=(k(1,1)+k(2,2))/(k(1,1)+k(1,2)+k(2,1)+k(2,2));;
    kk(i,1)=nOA;
    h=zeros(2,2);
    h(1,1)=sum(sum(m1==g1&m1~=0));
    h(1,2)=sum(sum(m1~=g1&m1==0));
    h(2,1)=sum(sum(m1~=g1&m1~=0));
    h(2,2)=sum(sum(m1==g1&m1==0));
    h=double(h);
    mOA=(h(1,1)+h(2,2))/(h(1,1)+h(1,2)+h(2,1)+h(2,2));;
    kk(i,2)=mOA;
    clear n1 m1 k h
end
kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    g1=imread(ipath+'1.tif');
    [m n]=size(g1);
%     kk(i,3)=double(sum(sum(n1==t1&n1~=0)))/m/n;
%     kk(i,4)=double(sum(sum(ms1==t1&m1~=0)))/m/n;
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==g1&n1~=0));
    k(1,2)=sum(sum(n1~=g1&n1==0));
    k(2,1)=sum(sum(n1~=g1&n1~=0));
    k(2,2)=sum(sum(n1==g1&n1==0));
    k=double(k);
    nprecision=k(1,1)/(k(1,1)+k(2,1));
    kk(i,1)=nprecision;
    h=zeros(2,2);
    h(1,1)=sum(sum(m1==g1&m1~=0));
    h(1,2)=sum(sum(m1~=g1&m1==0));
    h(2,1)=sum(sum(m1~=g1&m1~=0));
    h(2,2)=sum(sum(m1==g1&m1==0));
    h=double(h);
    mprecision=h(1,1)/(h(1,1)+h(2,1));
    kk(i,2)=mprecision;
    clear n1 m1 k h
end
kk=zeros(100,2);
for i=1:14
    ipath="C:\Users\SOULMATE\Desktop\double_experiment\data_cut_selected\orign\"+i+"\";
    n1=imread(ipath+'SubRGB_BW.tif');
    m1=imread(ipath+'mer5EXGR.tif');
    g1=imread(ipath+'1.tif');
    [m n]=size(g1);
    k=zeros(2,2);
    k(1,1)=sum(sum(n1==g1&n1~=0));
    k(1,2)=sum(sum(n1~=g1&n1==0));
    k(2,1)=sum(sum(n1~=g1&n1~=0));
    k(2,2)=sum(sum(n1==g1&n1==0));
    k=double(k);
    nprecision=k(1,1)/(k(1,1)+k(1,2));
    kk(i,1)=nprecision;
    h=zeros(2,2);
    h(1,1)=sum(sum(m1==g1&m1~=0));
    h(1,2)=sum(sum(m1~=g1&m1==0));
    h(2,1)=sum(sum(m1~=g1&m1~=0));
    h(2,2)=sum(sum(m1==g1&m1==0));
    h=double(h);
    mprecision=h(1,1)/(h(1,1)+h(1,2));
    kk(i,2)=mprecision;
    clear n1 m1 k h
end
