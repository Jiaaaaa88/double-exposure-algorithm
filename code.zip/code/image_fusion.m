for i=1:25
    ipath="C:\Users\SOULMATE\Desktop\double_exposed_data\"+i+"\";
    a1=imread(ipath+'nor.JPG');
    a2=imread(ipath+'hig5.JPG');
    [~,~,v1] = rgb2hsv(a1);
    a1=double(a1);
    a2=double(a2);
    ii=0.2;
    i1=find(v1<ii);
    aa1=a1(:,:,1);
    aa2=a2(:,:,1);
    aa1(i1)=aa1(i1)+aa2(i1).*((ii-v1(i1))/ii);
    b(:,:,1)=aa1;
    aa1=a1(:,:,2);
    aa2=a2(:,:,2);
    aa1(i1)=aa1(i1)+aa2(i1).*((ii-v1(i1))/ii);
    b(:,:,2)=aa1;
    aa1=a1(:,:,3);
    aa2=a2(:,:,3);
    aa1(i1)=aa1(i1)+aa2(i1).*((ii-v1(i1))/ii);
    b(:,:,3)=aa1;
    b=uint8(b);
    imwrite(b,ipath+'mer5.JPG')
    clear a1 a2 aa1 aa2 b i1 v1
end